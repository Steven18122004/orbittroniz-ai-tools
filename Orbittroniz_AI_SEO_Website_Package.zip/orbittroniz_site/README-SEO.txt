ORBITTRONIZ AI WEBSITE PACKAGE

Files: index.html (dashboard), individual SEO landing pages, About/Privacy/Terms/Contact, robots.txt and sitemap.xml.

BEFORE PUBLISHING:
1. Replace YOUR-DOMAIN.example in index.html canonical metadata, robots.txt, and sitemap.xml with the domain you actually own. If you do not own a custom domain yet, remove the canonical tag until you do.
2. Review Privacy Policy and Terms so they accurately describe your actual hosting, analytics, advertising, and third-party services.
3. Add a monitored public support email to contact.html.
4. Deploy all files together at the site root (for example GitHub Pages).
5. Verify the domain in Google Search Console, submit /sitemap.xml, and test the pages with URL Inspection.
6. SEO cannot guarantee rankings. Pages need useful original content, crawlable links, speed, and ongoing improvement.

FUNCTION NOTES:
- PDF merge loads PDF-Lib from jsDelivr CDN; needs internet.
- Text-to-speech uses browser/device speech synthesis; no MP3 export.
- Image merge/compression run in browser.
- GZIP creates .gz, not .zip.
- CSV converter handles common comma-separated rows with quoted fields, not every spreadsheet edge case.
